const mysql = require("mysql");

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "system",
    database: "node_food_delivery",
    port: 3308
});

connection.connect(function (error) {
    if (error) {
        console.log(error.message);
        return false;
    }
    // console.log("Database Connection Created");
});
module.exports = connection;